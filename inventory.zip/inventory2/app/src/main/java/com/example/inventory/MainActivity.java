package com.example.inventory;

import android.content.Intent;
import android.database.sqlite.SQLiteDatabase;
import android.database.Cursor;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {

    private EditText usernameInput, passwordInput;
    private Button loginButton, createAccountButton;
    private SQLiteDatabase db;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.login_screen);

        db = openOrCreateDatabase("InventoryApp", MODE_PRIVATE, null);
        db.execSQL("CREATE TABLE IF NOT EXISTS Users(Username TEXT PRIMARY KEY, Password TEXT)");

        usernameInput = findViewById(R.id.usernameInput);
        passwordInput = findViewById(R.id.passwordInput);
        loginButton = findViewById(R.id.loginButton);
        createAccountButton = findViewById(R.id.createAccountButton);

        loginButton.setOnClickListener(v -> {
            if (loginUser(usernameInput.getText().toString(), passwordInput.getText().toString())) {
                startActivity(new Intent(this, DataDisplayActivity.class));
                Toast.makeText(this, "Login Successful", Toast.LENGTH_SHORT).show();
            } else {
                Toast.makeText(this, "Invalid Login", Toast.LENGTH_SHORT).show();
            }
        });

        createAccountButton.setOnClickListener(v -> {
            if (createUser(usernameInput.getText().toString(), passwordInput.getText().toString())) {
                Toast.makeText(this, "Account Created", Toast.LENGTH_SHORT).show();
            } else {
                Toast.makeText(this, "Account Creation Failed", Toast.LENGTH_SHORT).show();
            }
        });
    }

    private boolean loginUser(String username, String password) {
        Cursor cursor = db.rawQuery("SELECT * FROM Users WHERE Username=? AND Password=?", new String[]{username, password});
        boolean isValid = cursor.getCount() > 0;
        cursor.close();
        return isValid;
    }

    private boolean createUser(String username, String password) {
        try {
            db.execSQL("INSERT INTO Users VALUES(?,?)", new Object[]{username, password});
            return true;
        } catch (Exception e) {
            return false;
        }
    }
}
