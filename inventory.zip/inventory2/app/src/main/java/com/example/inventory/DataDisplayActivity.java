package com.example.inventory;

import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import java.util.ArrayList;
import android.util.Log;


public class DataDisplayActivity extends AppCompatActivity {

    private RecyclerView recyclerView;
    private InventoryAdapter adapter;
    private DatabaseHelper dbHelper;
    private ArrayList<InventoryItem> inventoryList;
    private EditText itemNameInput, itemQuantityInput;
    private Button addItemButton;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.data_display_screen);

        dbHelper = new DatabaseHelper(this);

        itemNameInput = findViewById(R.id.itemNameInput);
        itemQuantityInput = findViewById(R.id.itemQuantityInput);
        addItemButton = findViewById(R.id.fabAddItem);
        recyclerView = findViewById(R.id.inventoryRecyclerView);

        recyclerView.setLayoutManager(new LinearLayoutManager(this));
        loadInventory();

        addItemButton.setOnClickListener(v -> {
            String name = itemNameInput.getText().toString().trim();
            String quantityText = itemQuantityInput.getText().toString().trim();

            if (!name.isEmpty() && !quantityText.isEmpty()) {
                int quantity = Integer.parseInt(quantityText);
                dbHelper.addItem(name, quantity);
                loadInventory(); // Reload RecyclerView
                itemNameInput.setText("");
                itemQuantityInput.setText("");
                Toast.makeText(this, "Item Added", Toast.LENGTH_SHORT).show();
            } else {
                Toast.makeText(this, "Please fill in all fields", Toast.LENGTH_SHORT).show();
            }
        });
    }

    private void loadInventory() {
        inventoryList = dbHelper.getAllItems(); // Get fresh data
        if (adapter == null) {
            adapter = new InventoryAdapter(this, inventoryList, dbHelper);
            recyclerView.setAdapter(adapter);
        } else {
            adapter.updateData(inventoryList);
        }
    }

}
