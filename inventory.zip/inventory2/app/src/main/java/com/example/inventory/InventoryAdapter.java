package com.example.inventory;

import android.app.AlertDialog;
import android.content.Context;
import android.text.InputType;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;
import android.util.Log;


import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;

public class InventoryAdapter extends RecyclerView.Adapter<InventoryAdapter.ViewHolder> {

    private ArrayList<InventoryItem> inventoryList;
    private Context context;
    private DatabaseHelper dbHelper;

    public InventoryAdapter(Context context, ArrayList<InventoryItem> inventoryList, DatabaseHelper dbHelper) {
        this.context = context;
        this.inventoryList = inventoryList;
        this.dbHelper = dbHelper;
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(context).inflate(R.layout.inventory_item, parent, false);
        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
        InventoryItem item = inventoryList.get(position);
        holder.itemName.setText(item.getName());
        holder.itemQuantity.setText(String.valueOf(item.getQuantity()));

        // Update button logic
        holder.updateButton.setOnClickListener(v -> showUpdateDialog(item, position));

        // Delete button logic
        holder.deleteButton.setOnClickListener(v -> {
            dbHelper.deleteItem(item.getName());
            refreshList(position);
            Toast.makeText(context, "Deleted Successfully", Toast.LENGTH_SHORT).show();
        });
    }

    @Override
    public int getItemCount() {
        return inventoryList.size();
    }

    private void showUpdateDialog(InventoryItem item, int position) {
        AlertDialog.Builder builder = new AlertDialog.Builder(context);
        builder.setTitle("Update Quantity");

        final EditText input = new EditText(context);
        input.setInputType(InputType.TYPE_CLASS_NUMBER);
        input.setHint("Enter New Quantity");
        builder.setView(input);

        builder.setPositiveButton("Update", (dialog, which) -> {
            String inputText = input.getText().toString();
            if (!inputText.isEmpty()) {
                int newQuantity = Integer.parseInt(inputText);
                dbHelper.updateItem(item.getName(), newQuantity);
                item.setQuantity(newQuantity);
                notifyItemChanged(position);
                Toast.makeText(context, "Updated Successfully", Toast.LENGTH_SHORT).show();
            } else {
                Toast.makeText(context, "Quantity cannot be empty", Toast.LENGTH_SHORT).show();
            }
        });

        builder.setNegativeButton("Cancel", null);
        builder.show();
    }

    private void refreshList(int position) {
        inventoryList.remove(position);
        notifyItemRemoved(position);
    }

    static class ViewHolder extends RecyclerView.ViewHolder {
        TextView itemName, itemQuantity;
        Button updateButton, deleteButton;

        public ViewHolder(@NonNull View itemView) {
            super(itemView);
            itemName = itemView.findViewById(R.id.itemName);
            itemQuantity = itemView.findViewById(R.id.itemQuantity);
            updateButton = itemView.findViewById(R.id.updateButton);
            deleteButton = itemView.findViewById(R.id.deleteButton);
        }
    }

    public void updateData(ArrayList<InventoryItem> newData) {
        inventoryList.clear();
        inventoryList.addAll(newData);
        notifyDataSetChanged(); // Refresh RecyclerView
    }

}
